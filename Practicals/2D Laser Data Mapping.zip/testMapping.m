clear all

% Define Map
xRange = 20;
yRange = 20;
mapResolution = 0.01;

% Create new Clear Map
% This is the "Prior"
map = startupMapping(xRange, yRange, mapResolution);


% Set/Get Robot Pose   - After Performing Action ** U **
pose = [5, 15, -pi/8];

% Get Laser Data       - Collecting Sensor Data  ** Z **
z = 3*ones(1,512)+rand(1,512)*0.5;
theta = linspace(-0.5, pi+0.5, 512);

%%% Evaluate Single Scan
map = addLaserScan(pose, theta, z, xRange, yRange, mapResolution);

%%% For Linear Probabilities, Apply Recursive Rule
% ?? 
%%% For Logodds ...
% ?? 

% Display Result
imagesc(map)
colormap(flipud(gray))
caxis([0 1]);
colorbar




