function [map] = addLaserScan(pose, theta, z, xRange, yRange, mapResolution)

persistent xint yint 

% For determining where LAser Beam goes across matrix determine grid
% intercepts
if isempty(xint)
    xint = linspace(0, xRange, xRange/mapResolution + 1); % List of x intercepts    
end
if isempty(yint)
    yint = linspace(0, yRange, yRange/mapResolution + 1); % List of y intercepts
end

map = startupMapping(xRange, yRange, mapResolution);

    % For each beam....
    for ii = 1:length(z)

        % Determine which line interceptions are relevant based on direction
        % off laser  % Note to self: could speed up withh logical indexing
        % here
        % Select Quadrant based on theta
        if mod(theta(ii)+pose(3) > 3*pi/2, 2*pi)
            % fourth quadrant
            xind = find(xint > pose(1));
            yind = find(yint < pose(2));
        elseif mod(theta(ii)+pose(3) > pi, 2*pi)
            % third quadrant
            xind = find(xint < pose(1));
            yind = find(yint < pose(2));
        elseif mod(theta(ii)+pose(3) > pi/2, 2*pi)
            xind = find(xint < pose(1));
            yind = find(yint > pose(2));
        else
            xind = find(xint > pose(1));
            yind = find(yint > pose(2));
        end
        x = xint(xind);
        y = yint(yind);

        % Using Line Gradient Form of y = mx+b, determine matching coordinates
        % for all line intercepts.
        line = [pose, theta(ii)];
        lxtheta = @(x,line) tan(line(3)+line(4))*(x-line(1))+line(2);
        lytheta = @(y,line) (y-line(2))/tan(line(3)+line(4))+line(1);
        vrt = [x', lxtheta(x,line)'];  % Vertical intercepts
        hrz = [lytheta(y,line)', y'];  % Horizonntal Intercepts
        hvix = [hrz; vrt];             % Concatanated  hrzw and ivrtt arrays with range

        %% Require Zone handling here.  
        %% Zone 1 = Cells < z - d1, 
        %% Zone 2 Cells > z - d1 but Cells > z + d1 and so one
            % Based on laser distance, remove cells that are past this distance
            ranges = sqrt((pose(1)-hvix(:,1)).*(pose(1)-hvix(:,1))+(pose(2)-hvix(:,2)).*(pose(2)-hvix(:,2)));
            exbd = find(ranges > z(ii));   % <<<<<<<<  HERE IS ZONE IMPLEMENTED
            hvix(exbd,:) = [];  % Blank cells that are not needed

            % Find matching cell coordinates in map, for a given position.  Take
            % note of comments in function positionInMap
            cellIndexes = [];
            for ii = 1:size(hvix,1)
                cellIndexes(ii,:) = positionInMap(hvix(ii,1), hvix(ii   ,2), xRange, yRange, mapResolution);
            end
            srtd = unique(cellIndexes,'rows');        % Remove repeats and sort ascending by %xs

            % Apply inverse sensor model to Map.
            map(srtd(:,2)*yRange/mapResolution+srtd(:,1)) = 1;  % <<<<<<<< VALUE APPLIED TO MAP HERE
    end



end

