function map = startupMapping(xrange, yrange, mapResolution)

map = 0.5*ones(xrange/mapResolution, yrange/mapResolution);